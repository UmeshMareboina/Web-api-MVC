﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using BookMVC.Helper;
using BookMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;


namespace BookMVC.Controllers
{
    public class HomeController : Controller
    {
        BookHelper bookhelper = new BookHelper();

        //get all data
        public async Task<IActionResult> Index()
        {
            List<BookData> books = new List<BookData>();
            HttpClient client = bookhelper.Initial();
            HttpResponseMessage res = await client.GetAsync("api/Book");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                books = JsonConvert.DeserializeObject<List<BookData>>(results);

            }
            return View(books);
        }

        //posting the detailes into DB
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult create(BookData book)
        {
            HttpClient client = bookhelper.Initial();
            var posttask = client.PostAsJsonAsync<BookData>("api/Book", book);
            posttask.Wait();
            var result = posttask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }



        //get single id detailes
        public async Task<IActionResult> Details(int Id)
        {
            BookData book = await GetBookById(Id);
            return View(book);
        }

        private async Task<BookData> GetBookById(int Id)
        {
            BookData book = new BookData();
            HttpClient client = bookhelper.Initial();
            HttpResponseMessage res = await client.GetAsync($"api/Book/{Id}");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                book = JsonConvert.DeserializeObject<BookData>(results);
            }

            return book;
        }

        //delete the data using Id
        public async Task<IActionResult> Delete(int Id)
        {
            var book = new BookData();
            HttpClient client = bookhelper.Initial();
            HttpResponseMessage res = await client.DeleteAsync($"api/Book/{Id}");
            return RedirectToAction("Index");

        }



        [HttpGet]
        public async Task<IActionResult> Edit(int Id)
        {
            BookData book = await GetBookById(Id);
            return View(book);

        }





        [HttpPost]
        public async Task<IActionResult> Edit(BookData book)
        {
            HttpClient client = bookhelper.Initial();


            HttpResponseMessage res = await client.PutAsJsonAsync($"api/Book?id=" + book.Id, book);

            if (res.IsSuccessStatusCode)
            {

                return RedirectToAction("Index");
            }

            return View();
        }


    }
}